
(() => {
  'use strict';
  const KEY = 'iraq-building-safety-survey-v1';
  const $ = (id) => document.getElementById(id);
  const today = new Date();
  const isoToday = `${today.getFullYear()}-${String(today.getMonth()+1).padStart(2,'0')}-${String(today.getDate()).padStart(2,'0')}`;
  let data = loadData();

  function loadData(){
    try {
      const raw = localStorage.getItem(KEY);
      if (!raw) return {buildings:[], inspections:[]};
      const parsed = JSON.parse(raw);
      if (!parsed || !Array.isArray(parsed.buildings) || !Array.isArray(parsed.inspections)) throw new Error('invalid');
      return parsed;
    } catch (e) {
      return {buildings:[], inspections:[]};
    }
  }
  function persist(){
    try { localStorage.setItem(KEY, JSON.stringify(data)); }
    catch (e) { alert('تعذّر حفظ البيانات. قد تكون مساحة التخزين ممتلئة؛ صدّر نسخة احتياطية واحذف بعض الملفات أو البيانات غير الضرورية.'); }
  }
  function uid(){ return `${Date.now().toString(36)}-${Math.random().toString(36).slice(2,8)}`; }
  function esc(value){ return String(value ?? '').replace(/[&<>"']/g, ch => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch])); }
  function buildingById(id){ return data.buildings.find(b => b.id === id); }
  function inspectionCount(id){ return data.inspections.filter(i => i.buildingId === id).length; }
  function fmtDate(v){ if(!v) return '—'; const p=String(v).split('-'); return p.length===3 ? `${p[2]}/${p[1]}/${p[0]}` : v; }
  function typeLabel(type){ return type === 'أول' ? 'كشف أول' : 'كشف متابعة'; }
  function setView(view){
    document.querySelectorAll('.view').forEach(el => el.classList.toggle('active', el.id === view));
    document.querySelectorAll('.nav button').forEach(el => el.classList.toggle('active', el.dataset.view === view));
    if(view === 'buildings') renderBuildings();
    if(view === 'inspections') { refreshBuildingOptions(); renderInspections(); }
    if(view === 'dashboard') renderDashboard();
    window.scrollTo({top:0, behavior:'smooth'});
  }
  function fillYearOptions(){
    const years = new Set([String(today.getFullYear()), ...data.inspections.map(i=>String(i.year))]);
    const ordered = [...years].sort((a,b)=>Number(b)-Number(a));
    const dash=$('dashboardYear'), filter=$('inspectionYearFilter');
    const oldDash=dash.value, oldFilter=filter.value;
    dash.innerHTML=ordered.map(y=>`<option value="${esc(y)}">${esc(y)}</option>`).join('');
    filter.innerHTML='<option value="">كل السنوات</option>'+ordered.map(y=>`<option value="${esc(y)}">${esc(y)}</option>`).join('');
    if(ordered.includes(oldDash)) dash.value=oldDash;
    if(ordered.includes(oldFilter)) filter.value=oldFilter;
  }
  function refreshBuildingOptions(){
    const select=$('iBuilding'), old=select.value;
    select.innerHTML='<option value="">اختر المبنى</option>'+data.buildings.slice().sort((a,b)=>a.name.localeCompare(b.name,'ar')).map(b=>`<option value="${esc(b.id)}">${esc(b.name)}${b.code?' — '+esc(b.code):''}</option>`).join('');
    if(data.buildings.some(b=>b.id===old)) select.value=old;
    const filter=$('inspectionBuildingFilter'), oldF=filter.value;
    filter.innerHTML='<option value="">كل المباني</option>'+data.buildings.slice().sort((a,b)=>a.name.localeCompare(b.name,'ar')).map(b=>`<option value="${esc(b.id)}">${esc(b.name)}</option>`).join('');
    if(data.buildings.some(b=>b.id===oldF)) filter.value=oldF;
  }
  function renderDashboard(){
    fillYearOptions();
    const year=Number($('dashboardYear').value || today.getFullYear());
    const yearIns=data.inspections.filter(i=>Number(i.year)===year);
    $('statBuildings').textContent=data.buildings.length;
    $('statInspections').textContent=yearIns.length;
    $('statFirst').textContent=yearIns.filter(i=>i.type==='أول').length;
    $('statFollow').textContent=yearIns.filter(i=>i.type==='متابعة').length;
    $('statInspectionHint').textContent=`للعام ${year}`;
    const rows=data.buildings.slice().sort((a,b)=>a.name.localeCompare(b.name,'ar')).map(b=>{
      const first=yearIns.some(i=>i.buildingId===b.id&&i.type==='أول');
      const follow=yearIns.some(i=>i.buildingId===b.id&&i.type==='متابعة');
      return `<tr><td><b>${esc(b.name)}</b><div class="muted">${esc(b.code||'')}</div></td><td>${esc(b.category)}</td><td>${esc(b.owner)}</td><td><span class="tag ${first?'ok':'missing'}">${first?'مسجل':'غير مسجل'}</span></td><td><span class="tag ${follow?'ok':'missing'}">${follow?'مسجل':'غير مسجل'}</span></td></tr>`;
    }).join('');
    $('dashboardStatus').innerHTML=rows || '<tr><td colspan="5" class="empty">لا توجد مبانٍ مسجلة بعد.</td></tr>';
    const recent=data.inspections.slice().sort((a,b)=>(b.date||'').localeCompare(a.date||'')).slice(0,6);
    $('recentInspections').innerHTML=recent.length ? recent.map(i=>{const b=buildingById(i.buildingId);return `<div style="padding:9px 0;border-bottom:1px solid #edf1ee"><b>${esc(b?.name||'مبنى محذوف')}</b><div class="muted" style="font-size:11px">${esc(typeLabel(i.type))} · ${fmtDate(i.date)} · ${esc(i.year)}</div></div>`}).join('') : '<div class="empty">لا توجد كشوفات حتى الآن.</div>';
  }
  function renderBuildings(){
    const q=$('buildingSearch').value.trim().toLowerCase(), cls=$('buildingClassFilter').value, own=$('buildingOwnershipFilter').value;
    const list=data.buildings.filter(b=>{
      const hay=[b.name,b.code,b.owner,b.ownership,b.mgrs,b.address].join(' ').toLowerCase();
      return (!q||hay.includes(q))&&(!cls||b.category===cls)&&(!own||b.ownership===own);
    }).sort((a,b)=>a.name.localeCompare(b.name,'ar'));
    $('buildingsTable').innerHTML=list.map(b=>`<tr>
      <td><b>${esc(b.name)}</b>${b.code?`<div class="muted">الرمز: ${esc(b.code)}</div>`:''}</td><td><span class="tag">${esc(b.category)}</span></td><td>${esc(b.ownership)}</td><td>${esc(b.owner)}</td><td dir="ltr" class="nowrap">${esc(b.mgrs||'—')}</td><td>${inspectionCount(b.id)}</td>
      <td><div class="actions"><button class="btn btn-small btn-outline" data-action="details-building" data-id="${esc(b.id)}">عرض</button><button class="btn btn-small btn-outline" data-action="edit-building" data-id="${esc(b.id)}">تعديل</button><button class="btn btn-small btn-primary" data-action="add-inspection" data-id="${esc(b.id)}">إضافة كشف</button><button class="btn btn-small btn-danger" data-action="delete-building" data-id="${esc(b.id)}">حذف</button></div></td>
    </tr>`).join('');
    $('buildingsEmpty').classList.toggle('hidden',list.length>0);
  }
  function renderInspections(){
    fillYearOptions(); refreshBuildingOptions();
    const q=$('inspectionSearch').value.trim().toLowerCase(), year=$('inspectionYearFilter').value, bid=$('inspectionBuildingFilter').value, type=$('inspectionTypeFilter').value;
    const list=data.inspections.filter(i=>{
      const b=buildingById(i.buildingId); const hay=[b?.name,b?.owner,i.plan,i.outgoing,i.notes,i.date].join(' ').toLowerCase();
      return (!q||hay.includes(q))&&(!year||String(i.year)===year)&&(!bid||i.buildingId===bid)&&(!type||i.type===type);
    }).sort((a,b)=>(b.date||'').localeCompare(a.date||'')||Number(b.year)-Number(a.year));
    $('inspectionsTable').innerHTML=list.map(i=>{const b=buildingById(i.buildingId);const notes=(i.notes||'').trim();return `<tr>
      <td><b>${esc(b?.name||'مبنى غير موجود')}</b><div class="muted">${esc(b?.owner||'')}</div></td><td>${esc(i.year)}</td><td><span class="tag">${esc(typeLabel(i.type))}</span></td><td class="nowrap">${fmtDate(i.date)}</td><td>${esc(i.plan||'—')}</td><td>${esc(i.outgoing||'—')}</td><td class="note-cell">${notes?esc(notes):'<span class="muted">لا توجد ملاحظات</span>'}</td>
      <td><div class="actions"><button class="btn btn-small btn-outline" data-action="edit-inspection" data-id="${esc(i.id)}">تعديل</button><button class="btn btn-small btn-danger" data-action="delete-inspection" data-id="${esc(i.id)}">حذف</button></div></td>
    </tr>`}).join('');
    $('inspectionsEmpty').classList.toggle('hidden',list.length>0);
  }
  function resetBuildingForm(){ $('buildingForm').reset();$('buildingId').value='';$('bClass').value='أ';$('bOwnership').value='حكومي';$('buildingFormTitle').textContent='بيانات المبنى';$('saveBuildingBtn').textContent='حفظ بيانات المبنى'; }
  function resetInspectionForm(){ $('inspectionForm').reset();$('inspectionId').value='';$('iYear').value=today.getFullYear();$('iDate').value=isoToday;$('iType').value='أول';$('inspectionFormTitle').textContent='بيانات الكشف';$('saveInspectionBtn').textContent='حفظ الكشف'; }
  function editBuilding(id){
    const b=buildingById(id); if(!b)return;
    $('buildingId').value=b.id;$('bName').value=b.name;$('bCode').value=b.code||'';$('bClass').value=b.category;$('bOwnership').value=b.ownership;$('bOwner').value=b.owner;$('bMgrs').value=b.mgrs||'';$('bAddress').value=b.address||'';
    $('buildingFormTitle').textContent='تعديل بيانات المبنى';$('saveBuildingBtn').textContent='حفظ التعديلات';$('buildingFormPanel').scrollIntoView({behavior:'smooth',block:'start'});
  }
  function editInspection(id){
    const i=data.inspections.find(x=>x.id===id); if(!i)return;
    refreshBuildingOptions();$('inspectionId').value=i.id;$('iBuilding').value=i.buildingId;$('iType').value=i.type;$('iYear').value=i.year;$('iDate').value=i.date;$('iPlan').value=i.plan||'';$('iOutgoing').value=i.outgoing||'';$('iNotes').value=i.notes||'';
    $('inspectionFormTitle').textContent='تعديل بيانات الكشف';$('saveInspectionBtn').textContent='حفظ التعديلات';$('inspectionFormPanel').scrollIntoView({behavior:'smooth',block:'start'});
  }
  function showBuildingDetails(id){
    const b=buildingById(id);if(!b)return;
    $('detailTitle').textContent=b.name;
    const records=data.inspections.filter(i=>i.buildingId===id).sort((a,b)=>(b.date||'').localeCompare(a.date||''));
    $('detailContent').innerHTML=`<div class="details-grid"><div class="detail"><span>الصنف</span><b>${esc(b.category)}</b></div><div class="detail"><span>نوع العائدية</span><b>${esc(b.ownership)}</b></div><div class="detail"><span>العائدية</span><b>${esc(b.owner)}</b></div><div class="detail"><span>رمز المبنى</span><b>${esc(b.code||'—')}</b></div><div class="detail"><span>إحداثيات MGRS</span><b dir="ltr">${esc(b.mgrs||'—')}</b></div><div class="detail"><span>العنوان</span><b>${esc(b.address||'—')}</b></div></div><h4>سجل الكشوفات (${records.length})</h4>${records.length?`<div class="table-wrap"><table><thead><tr><th>السنة</th><th>النوع</th><th>التاريخ</th><th>تسلسل الخطة</th><th>رقم الصادر</th><th>الملاحظات</th></tr></thead><tbody>${records.map(i=>`<tr><td>${esc(i.year)}</td><td>${esc(typeLabel(i.type))}</td><td>${fmtDate(i.date)}</td><td>${esc(i.plan||'—')}</td><td>${esc(i.outgoing||'—')}</td><td class="note-cell">${esc(i.notes||'—')}</td></tr>`).join('')}</tbody></table></div>`:'<div class="empty">لا توجد كشوفات مسجلة لهذا المبنى.</div>'}`;
    $('detailModal').classList.add('open');
  }
  function exportBackup(){
    const payload={app:'نظام متابعة كشوفات السلامة',version:1,exportedAt:new Date().toISOString(),...data};
    downloadBlob(JSON.stringify(payload,null,2),'backup-kashf-salama-'+isoToday+'.json','application/json;charset=utf-8');
  }
  function downloadBlob(content,name,type){
    const blob=new Blob([content],{type});const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download=name;document.body.appendChild(a);a.click();a.remove();URL.revokeObjectURL(url);
  }
  function exportCsv(){
    const rows=[['اسم المبنى','رمز المبنى','الصنف','نوع العائدية','العائدية','MGRS','العنوان','السنة','نوع الكشف','تاريخ الكشف','تسلسل الخطة','رقم الصادر','الملاحظات']];
    data.inspections.forEach(i=>{const b=buildingById(i.buildingId)||{};rows.push([b.name,b.code,b.category,b.ownership,b.owner,b.mgrs,b.address,i.year,typeLabel(i.type),i.date,i.plan,i.outgoing,i.notes]);});
    const csv='\uFEFF'+rows.map(r=>r.map(v=>'"'+String(v??'').replace(/"/g,'""')+'"').join(',')).join('\r\n');
    downloadBlob(csv,'kashofat-'+isoToday+'.csv','text/csv;charset=utf-8');
  }
  function printReport(){
    const year=$('inspectionYearFilter').value||String(today.getFullYear());
    const list=data.inspections.filter(i=>String(i.year)===year).sort((a,b)=>(a.date||'').localeCompare(b.date||''));
    $('printArea').innerHTML=`<h1>تقرير كشوفات السلامة للمباني</h1><p>السنة: ${esc(year)} | تاريخ الطباعة: ${fmtDate(isoToday)} | عدد الكشوفات: ${list.length}</p><table><thead><tr><th>المبنى</th><th>الصنف</th><th>العائدية</th><th>MGRS</th><th>نوع الكشف</th><th>تاريخ الكشف</th><th>تسلسل الخطة</th><th>رقم الصادر</th><th>الملاحظات السلبية</th></tr></thead><tbody>${list.map(i=>{const b=buildingById(i.buildingId)||{};return `<tr><td>${esc(b.name||'')}</td><td>${esc(b.category||'')}</td><td>${esc(b.owner||'')}</td><td dir="ltr">${esc(b.mgrs||'')}</td><td>${esc(typeLabel(i.type))}</td><td>${fmtDate(i.date)}</td><td>${esc(i.plan||'')}</td><td>${esc(i.outgoing||'')}</td><td class="print-notes">${esc(i.notes||'')}</td></tr>`}).join('')}</tbody></table>`;
    window.print();
  }

  document.querySelectorAll('.nav button').forEach(btn=>btn.addEventListener('click',()=>setView(btn.dataset.view)));
  $('dashboardYear').addEventListener('change',renderDashboard);
  ['buildingSearch','buildingClassFilter','buildingOwnershipFilter'].forEach(id=>$(id).addEventListener(id==='buildingSearch'?'input':'change',renderBuildings));
  ['inspectionSearch','inspectionYearFilter','inspectionBuildingFilter','inspectionTypeFilter'].forEach(id=>$(id).addEventListener(id==='inspectionSearch'?'input':'change',renderInspections));
  $('newBuildingBtn').addEventListener('click',()=>{resetBuildingForm();$('buildingFormPanel').scrollIntoView({behavior:'smooth',block:'start'});$('bName').focus();});
  $('cancelBuildingEdit').addEventListener('click',resetBuildingForm);
  $('buildingForm').addEventListener('submit',e=>{
    e.preventDefault();
    const id=$('buildingId').value;
    const record={id:id||uid(),name:$('bName').value.trim(),code:$('bCode').value.trim(),category:$('bClass').value,ownership:$('bOwnership').value,owner:$('bOwner').value.trim(),mgrs:$('bMgrs').value.trim().toUpperCase(),address:$('bAddress').value.trim()};
    if(!record.name||!record.owner){alert('يرجى إدخال اسم المبنى والعائدية.');return;}
    if(id){data.buildings=data.buildings.map(b=>b.id===id?record:b);}else{data.buildings.push(record);}
    persist();resetBuildingForm();refreshBuildingOptions();renderBuildings();renderDashboard();
    alert(id?'تم تحديث بيانات المبنى.':'تمت إضافة المبنى بنجاح.');
  });
  $('newInspectionBtn').addEventListener('click',()=>{resetInspectionForm();refreshBuildingOptions();if(!data.buildings.length){alert('أضف مبنى أولاً قبل تسجيل الكشف.');setView('buildings');return;}$('inspectionFormPanel').scrollIntoView({behavior:'smooth',block:'start'});$('iBuilding').focus();});
  $('cancelInspectionEdit').addEventListener('click',resetInspectionForm);
  $('inspectionForm').addEventListener('submit',e=>{
    e.preventDefault();
    const id=$('inspectionId').value, buildingId=$('iBuilding').value, type=$('iType').value, year=Number($('iYear').value);
    if(!buildingById(buildingId)){alert('اختر مبنى مسجلاً.');return;}
    if(!Number.isInteger(year)||year<2000||year>2100){alert('أدخل سنة صحيحة.');return;}
    const duplicate=data.inspections.find(i=>i.id!==id&&i.buildingId===buildingId&&Number(i.year)===year&&i.type===type);
    if(duplicate){alert(`يوجد ${typeLabel(type)} مسجل لهذا المبنى في سنة ${year}. يمكنك تعديل الكشف الموجود من جدول الكشوفات.`);return;}
    const record={id:id||uid(),buildingId,type,year,date:$('iDate').value,plan:$('iPlan').value.trim(),outgoing:$('iOutgoing').value.trim(),notes:$('iNotes').value.trim()};
    if(!record.date){alert('أدخل تاريخ الكشف.');return;}
    if(id){data.inspections=data.inspections.map(i=>i.id===id?record:i);}else{data.inspections.push(record);}
    persist();resetInspectionForm();renderInspections();renderDashboard();
    alert(id?'تم تحديث الكشف.':'تم حفظ الكشف بنجاح.');
  });
  document.body.addEventListener('click',e=>{
    const btn=e.target.closest('[data-action]');if(!btn)return;
    const {action,id}=btn.dataset;
    if(action==='details-building')showBuildingDetails(id);
    if(action==='edit-building')editBuilding(id);
    if(action==='add-inspection'){
      resetInspectionForm();refreshBuildingOptions();$('iBuilding').value=id;setView('inspections');$('iBuilding').value=id;$('inspectionFormPanel').scrollIntoView({behavior:'smooth',block:'start'});
    }
    if(action==='delete-building'){
      const b=buildingById(id);if(!b)return;
      if(confirm(`حذف المبنى «${b.name}» وكل الكشوفات المرتبطة به؟ لا يمكن التراجع عن هذه العملية.`)){
        data.buildings=data.buildings.filter(x=>x.id!==id);data.inspections=data.inspections.filter(x=>x.buildingId!==id);persist();refreshBuildingOptions();renderBuildings();renderInspections();renderDashboard();
      }
    }
    if(action==='edit-inspection')editInspection(id);
    if(action==='delete-inspection'){
      if(confirm('هل تريد حذف هذا الكشف؟')){data.inspections=data.inspections.filter(x=>x.id!==id);persist();renderInspections();renderDashboard();}
    }
  });
  $('closeModal').addEventListener('click',()=>$('detailModal').classList.remove('open'));
  $('detailModal').addEventListener('click',e=>{if(e.target===$('detailModal'))$('detailModal').classList.remove('open');});
  $('exportBtn').addEventListener('click',exportBackup);
  $('importBtn').addEventListener('click',()=>$('importFile').click());
  $('importFile').addEventListener('change',async e=>{
    const file=e.target.files?.[0];if(!file)return;
    try{
      const parsed=JSON.parse(await file.text());
      if(!parsed||!Array.isArray(parsed.buildings)||!Array.isArray(parsed.inspections))throw new Error('bad format');
      if(!confirm(`سيتم استبدال البيانات الحالية بـ ${parsed.buildings.length} مبنى و${parsed.inspections.length} كشف من النسخة الاحتياطية. هل تريد المتابعة؟`))return;
      data={buildings:parsed.buildings,inspections:parsed.inspections};persist();resetBuildingForm();resetInspectionForm();refreshBuildingOptions();renderBuildings();renderInspections();renderDashboard();alert('تم استيراد النسخة الاحتياطية.');
    }catch(err){alert('تعذّر استيراد الملف. تأكد من اختيار نسخة احتياطية صادرة من التطبيق.');}
    finally{e.target.value='';}
  });
  $('exportCsvBtn').addEventListener('click',exportCsv);
  $('printReportBtn').addEventListener('click',printReport);

  resetBuildingForm();resetInspectionForm();fillYearOptions();refreshBuildingOptions();renderDashboard();renderBuildings();renderInspections();
})();
