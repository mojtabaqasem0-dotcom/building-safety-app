مشروع تطبيق كشوفات سلامة المباني لنظام Android

هذا مشروع مصدر جاهز للفتح في Android Studio، وليس ملف APK مبنياً.

طريقة إنشاء APK:
1) افتح Android Studio على كمبيوتر.
2) اختر Open وافتح مجلد field_survey_android.
3) انتظر اكتمال Gradle Sync.
4) من القائمة Build اختر Build Bundle(s) / APK(s) ثم Build APK(s).
5) بعد نجاح البناء اضغط Locate للوصول إلى app-debug.apk.
6) انقل APK إلى الهاتف وثبته. قد يطلب Android السماح بالتثبيت من هذا المصدر.

التطبيق يعرض ملفات HTML/JS محلياً داخل WebView ولا يحتاج اتصالاً بالإنترنت.
